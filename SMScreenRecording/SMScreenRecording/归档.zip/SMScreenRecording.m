//
//  SMScreenRecording.m
//  SMScreenRecording
//
//  Created by 朱思明 on 2017/5/13.
//  Copyright © 2017年 朱思明. All rights reserved.
//

#import "SMScreenRecording.h"


@implementation SMScreenRecording

- (instancetype)init
{
    self = [super init];
    if (self) {
        // 01 创建获取截图队列
        _concurrent_getImage_queue = dispatch_queue_create("concurrent", DISPATCH_QUEUE_CONCURRENT);
        
        // 02 创建写入视频队列
        _serial_writeVideo_queue = dispatch_queue_create("serial", DISPATCH_QUEUE_SERIAL);
    }
    return self;
}

/*
 *  单例方法
 */
+ (SMScreenRecording *)shareManager
{
    static SMScreenRecording *screenRecording = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        screenRecording = [[SMScreenRecording alloc] init];
    });
    return screenRecording;
}

/*
 *  开始录制屏幕
 *
 *  params: 指定视图的填充位置，可以录制指定区域
 */
- (void)startScreenRecordingWithScreenView:(UIView *)screenView failureBlock:(FailureBlock)failureBlock
{
    // 保存需要录制的视图
    _screenView = screenView;
    // 01 初始化帧数
    _frames_number = 1;

    // 03 移除路径里面的数据
    [[NSFileManager defaultManager] removeItemAtPath:kMoviePath error:NULL];
    // 04 视频转换设置
    NSError *error = nil;
    _videoWriter = [[AVAssetWriter alloc] initWithURL:[NSURL fileURLWithPath:kMoviePath]
                                                           fileType:AVFileTypeQuickTimeMovie
                                                              error:&error];
    
    NSParameterAssert(_videoWriter);
    
    NSDictionary *videoSettings = @{AVVideoCodecKey: AVVideoCodecH264,
                                    AVVideoWidthKey: [NSNumber numberWithFloat:screenView.frame.size.width * kScreenScale],
                                    AVVideoHeightKey: [NSNumber numberWithFloat:screenView.frame.size.height * kScreenScale]};
    
    _writerInput = [AVAssetWriterInput assetWriterInputWithMediaType:AVMediaTypeVideo
                                                                         outputSettings:videoSettings];
    
    _adaptor = [AVAssetWriterInputPixelBufferAdaptor assetWriterInputPixelBufferAdaptorWithAssetWriterInput:_writerInput
                                                                                                                     sourcePixelBufferAttributes:nil];
    // 05 保存block
    self.failureBlock = failureBlock;
    
    NSParameterAssert(_writerInput);
    NSParameterAssert([_videoWriter canAddInput:_writerInput]);
    [_videoWriter addInput:_writerInput];
    //Start a session:
    [_videoWriter startWriting];
    [_videoWriter startSessionAtSourceTime:kCMTimeZero];
    
    // 06
    // 创建定时器
    _timer = [NSTimer scheduledTimerWithTimeInterval:(1.0 / kFrames) target:self selector:@selector(timerAction:) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];
}

/*
 *  停止录制屏幕
 *
 *  FinishBlock: 错误信息，视频地址
 */
- (void)endScreenRecordingWithFinishBlock:(FinishBlock) finishBlock;
{
    if (_timer == nil) {
        return;
    }
    self.finishBlock = finishBlock;
    // 01 通知多线程停止操作
//    [self performSelector:@selector(threadend) onThread:_timer_thread withObject:nil waitUntilDone:YES];
    [_timer invalidate];
    _timer = nil;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), _serial_writeVideo_queue, ^{
        [_writerInput markAsFinished];
        [_videoWriter finishWritingWithCompletionHandler:^{
            NSLog(@"Successfully closed video writer");
            dispatch_async(dispatch_get_main_queue(), ^{
                if (_videoWriter.status == AVAssetWriterStatusCompleted) {
                    NSLog(@"成功");
                    if (self.finishBlock != nil) {
                        self.finishBlock(nil, kMoviePath);
                    }
                } else {
                    NSLog(@"失败");
                    if (self.finishBlock != nil) {
                        NSError *error = [NSError errorWithDomain:@"录制失败" code:-1 userInfo:nil];
                        self.finishBlock(error, nil);
                    }
                }
                _writerInput = nil;
                _videoWriter = nil;
                _adaptor = nil;
            });
        }];
    });

}

// 获取当前屏幕的截图图片
- (UIImage *)getScreenRecordingImage
{
    // 01 获取当前视图的截图
    //    UIGraphicsBeginImageContext(self.frame.size);
    // 判断是否为retina屏, 即retina屏绘图时有放大因子
    if ([[UIScreen mainScreen] respondsToSelector:@selector(scale)]){
        UIGraphicsBeginImageContextWithOptions(_screenView.bounds.size, NO, kScreenScale);
    } else {
        UIGraphicsBeginImageContext(_screenView.bounds.size);
    }
    // 可以截取视频或者绘制元素
    [_screenView drawViewHierarchyInRect:_screenView.bounds afterScreenUpdates:false];
//        [_screenView.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *screenshotImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    // 02 修正当前图片的大小位置和尺寸
    return screenshotImage;
}

// 图片转换成流视频对象
- (CVPixelBufferRef)pixelBufferFromCGImage:(CGImageRef)image{
    
    NSDictionary *options = [NSDictionary dictionaryWithObjectsAndKeys:
                             [NSNumber numberWithBool:YES], kCVPixelBufferCGImageCompatibilityKey,
                             [NSNumber numberWithBool:YES], kCVPixelBufferCGBitmapContextCompatibilityKey,
                             nil];
    
    CVPixelBufferRef pxbuffer = NULL;
    // 获取图片的大小
    CGFloat frameWidth = CGImageGetWidth(image);
    CGFloat frameHeight = CGImageGetHeight(image);
    // 转流设置
    CVReturn status = CVPixelBufferCreate(kCFAllocatorDefault,
                                          frameWidth,
                                          frameHeight,
                                          kCVPixelFormatType_32ARGB,
                                          (__bridge CFDictionaryRef) options,
                                          &pxbuffer);
    
    NSParameterAssert(status == kCVReturnSuccess && pxbuffer != NULL);
    
    CVPixelBufferLockBaseAddress(pxbuffer, 0);
    void *pxdata = CVPixelBufferGetBaseAddress(pxbuffer);
    NSParameterAssert(pxdata != NULL);
    
    CGColorSpaceRef rgbColorSpace = CGColorSpaceCreateDeviceRGB();
    
    CGContextRef context = CGBitmapContextCreate(pxdata,
                                                 frameWidth,
                                                 frameHeight,
                                                 8,
                                                 CVPixelBufferGetBytesPerRow(pxbuffer),
                                                 rgbColorSpace,
                                                 (CGBitmapInfo)kCGImageAlphaNoneSkipFirst);
    NSParameterAssert(context);
    CGContextConcatCTM(context, CGAffineTransformIdentity);
    CGContextDrawImage(context, CGRectMake(0,
                                           0,
                                           frameWidth,
                                           frameHeight),
                       image);
    CGColorSpaceRelease(rgbColorSpace);
    CGContextRelease(context);
    
    CVPixelBufferUnlockBaseAddress(pxbuffer, 0);
    
    return pxbuffer;
}

// 定时器事件
- (void)timerAction:(NSTimer *)timer
{
    dispatch_async(_concurrent_getImage_queue, ^{
        NSLog(@"耗时开始");
        // 1.获取当前帧下的图片
        UIImage *screenImage = [self getScreenRecordingImage]; // cpu 15
        // cpu 15
        //                      CVPixelBufferRef buffer = (CVPixelBufferRef)[self pixelBufferFromCGImage:imageRef size:inRect.size];
        CVPixelBufferRef buffer = [self pixelBufferFromCGImage:screenImage.CGImage]; // cpu 15
        // 2.帧数改变
        dispatch_sync(_serial_writeVideo_queue, ^{
            [self wirteVideoWithBuffer:buffer];
        });
        CVPixelBufferRelease(buffer);
    });
    
}

// 图片写入视频流
- (void)wirteVideoWithBuffer:(CVPixelBufferRef)buf {
    CVPixelBufferRef buffer = CVPixelBufferRetain(buf);
    if (buffer) {
        NSLog(@"buffer:frame %d",_frames_number);
        @try {
            if(![_adaptor appendPixelBuffer:buffer withPresentationTime:CMTimeMake(_frames_number, kFrames)]) {
                NSLog(@"FAIL");
                if (_timer == nil) {
                    return;
                }
                // 1.停止定时器
                [_timer invalidate];
                _timer = nil;
                [_writerInput markAsFinished];
                [_videoWriter finishWritingWithCompletionHandler:^{
                    NSLog(@"Successfully closed video writer");
                    dispatch_async(dispatch_get_main_queue(), ^{
                        // 4.回调失败的block
                        if (self.failureBlock != Nil) {
                            NSError *error = [NSError errorWithDomain:@"录制失败" code:-1 userInfo:nil];
                            self.failureBlock(error);
                        }
                    });
                    _writerInput = nil;
                    _videoWriter = nil;
                    _adaptor = nil;
                }];
            } else {
                CVPixelBufferRelease(buffer);
                _frames_number++;
            }
        } @catch (NSException *exception) {
            NSLog(@"try异常处理%@",exception);
            if (_timer == nil) {
                return;
            }
            // 1.停止定时器
            [_timer invalidate];
            _timer = nil;
            [_writerInput markAsFinished];
            [_videoWriter finishWritingWithCompletionHandler:^{
                NSLog(@"Successfully closed video writer");
                dispatch_async(dispatch_get_main_queue(), ^{
                    // 4.回调失败的block
                    if (self.failureBlock != Nil) {
                        NSError *error = [NSError errorWithDomain:@"录制失败" code:-1 userInfo:nil];
                        self.failureBlock(error);
                    }
                });
                _writerInput = nil;
                _videoWriter = nil;
                _adaptor = nil;
            }];
        } @finally {
        }
    } else {
        CVPixelBufferRelease(buffer);
    }
}

@end
